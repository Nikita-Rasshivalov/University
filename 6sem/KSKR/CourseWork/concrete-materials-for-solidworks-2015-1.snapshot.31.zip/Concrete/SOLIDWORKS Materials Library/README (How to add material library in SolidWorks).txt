		--How to add material library in SolidWorks--

1) Copy the file "Filename.sldmat" in the folder "C:\ProgramData\SOLIDWORKS\SOLIDWORKS 201X\Custom Materials"
	(the folder "C:\ProgramData" is hidden by default in Windows)
2) Open a new part in SolidWorks to see if the library is visible, applying a material to the part.

